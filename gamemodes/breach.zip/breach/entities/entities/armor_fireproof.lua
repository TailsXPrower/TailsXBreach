AddCSLuaFile()

ENT.Base		= "armor_base"
ENT.PrintName	= "Fireproof Vest"
ENT.ArmorType	= "armor_fireproof"