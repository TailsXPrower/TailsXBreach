AddCSLuaFile()

ENT.Base		= "armor_base"
ENT.PrintName	= "Hazmat Suit"
ENT.ArmorType	= "armor_hazmat"