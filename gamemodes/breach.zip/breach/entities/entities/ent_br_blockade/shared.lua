ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.PrintName = "Blockade"
ENT.Author = "Kanade"
ENT.Contact = "Steam"
ENT.Purpose = ""
ENT.Instructions = ""
ENT.Spawnable = false
ENT.AdminSpawnable = false