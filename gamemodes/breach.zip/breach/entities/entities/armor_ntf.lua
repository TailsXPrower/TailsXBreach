AddCSLuaFile()

ENT.Base		= "armor_base"
ENT.PrintName	= "NTF Vest"
ENT.ArmorType	= "armor_ntf"