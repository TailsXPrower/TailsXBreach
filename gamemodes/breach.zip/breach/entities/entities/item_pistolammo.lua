AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "breach_baseammo"
ENT.AmmoID = 2
ENT.AmmoType = "Pistol"
ENT.AmmoAmount = 64
ENT.MaxUses = 2
ENT.Model = Model("models/items/boxsrounds.mdl")