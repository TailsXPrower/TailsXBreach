AddCSLuaFile()

ENT.Base		= "armor_base"
ENT.PrintName	= "MTF Commander Vest"
ENT.ArmorType	= "armor_mtfcom"