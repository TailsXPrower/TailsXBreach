AddCSLuaFile()

ENT.Base		= "armor_base"
ENT.PrintName	= "MTF Medic Vest"
ENT.ArmorType	= "armor_mtfmedic"