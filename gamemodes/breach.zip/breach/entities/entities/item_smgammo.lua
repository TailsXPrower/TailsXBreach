AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "breach_baseammo"
ENT.AmmoID = 1
ENT.AmmoType = "SMG1"
ENT.PName = "SMG Ammo"
ENT.AmmoAmount = 125
ENT.MaxUses = 2
ENT.Model = Model("models/items/boxmrounds.mdl")