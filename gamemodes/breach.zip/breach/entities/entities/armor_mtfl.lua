AddCSLuaFile()

ENT.Base		= "armor_base"
ENT.PrintName	= "MTFL Vest"
ENT.ArmorType	= "armor_mtfl"