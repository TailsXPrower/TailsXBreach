AddCSLuaFile()

ENT.Base		= "armor_base"
ENT.PrintName	= "Chaos Insurgency Vest"
ENT.ArmorType	= "armor_chaosins"