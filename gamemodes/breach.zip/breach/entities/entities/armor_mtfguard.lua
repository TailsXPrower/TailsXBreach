AddCSLuaFile()

ENT.Base		= "armor_base"
ENT.PrintName	= "MTF Guard Vest"
ENT.ArmorType	= "armor_mtfguard"